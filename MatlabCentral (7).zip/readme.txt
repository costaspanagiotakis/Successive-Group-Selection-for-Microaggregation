 This code is a simple(not speed optimized) implementation of GSMS_T2 
 based on the paper [1]. This implementaion does not use the speed
 optimazations of [1]. 

You can find more details in www.csd.uoc.gr/~cpanag and www.csd.uoc.gr/~tziritas 

Files: 
   GSMS_T2.m implemetation of the method
   data.mat: Tarragona dataset (834 records with 13 numerical attributes).
   synthetic216.zip:  The 216 synthetic datasets  that have been used in [1]. 
   usage to run GSMS_T2 using K = 5 on Tarragona dataset:
       
       load data;
       [SSE, L, P, numC] = GSMS_T2(Data,5,1); 


usage to run GSMS using K = 5 on Tarragona dataset:
       
       load data;
       [SSE, L, P, numC] = GSMS_T2(Data,5,0); 



[1] C. Panagiotakis and G. Tziritas, Successive Group Selection for Microaggregation, 
IEEE Trans. on Knowledge and Data Engineering, vol.25, no.5, pp.1191-1195, May 2013.
