
% This code is a simple(not speed optimized) implementation of GSMS_T2 
% based on the paper [1]. This implementaion does not use the speed
% optimazations of [1]. 
%  [1] . C. Panagiotakis and G. Tziritas, Successive Group Selection for Microaggregation, IEEE Trans. on Knowledge and Data Engineering, vol.25, no.5, pp.1191-1195, May 2013.
%
% You can use this software for non commercial purposes. Please, cite the article [1].
% If you want to use the software for commercial purpose you have to contact with the authors of [1].
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input:
%   Data: N x p matrix of dataset where N is the number of records
%   and p the number of attributes 
%   K: the minimum size of each group (parameter of Microaggregation problem), 
%   runTFRP2 is 1 to run second part of TFRP method, else runTFRP2 is 0
%   (GSMS method)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output:
%   SSE: sum of the within-partition squared error (SSE)
%   L: standardized information loss measure 
%   numC: Number of Clusters (groups)
%   P: Partition in matrix form. The number of matrix lines are numC 

function [SSE, L, P, numC]= GSMS_T2(Data,K,runTFRP2)

[SSE, numC,P,N] = GSMS(Data,K); %GSMS method 

if runTFRP2 == 1,
    [SSE, numC,P,N] = TFRP_P2(Data,K,P,N,numC); %second part of TFRP method 
end

SST = getSST(Data);
L = SSE/SST;



function [SSE,numC,P,N] = improvePartitionDiameterCrit(Data,Pold,Nold,K)

S = size(Pold,1);
newClusters = 0;
SSE = 0;
P = Pold;
N = Nold;
for comp=1:S,
    nodes = Pold(comp,1:Nold(comp));
    
    if length(nodes) >= 2*K 
          [SSEnew, numCnew,P1,N1] = diameterBasedFixedSize(Data(nodes,:),K);
          SSE = SSE + SSEnew;
          
          for j=1:numCnew,
            P(comp+newClusters+j-1,1:N1(j)) = P1(j,1:N1(j));
            N(comp+newClusters+j-1) = N1(j);
          end

          newClusters = newClusters+numCnew-1;
    else
         P(comp+newClusters,1:length(nodes)) = nodes;
         N(comp+newClusters) = length(nodes);
         SSE = SSE + getSSE(Data,nodes);
    end
end

numC = S+newClusters;

%SSE
%numC

function [a1,S] =  gather(Data,S,a,K)

S = setdiff(S, a);
a1 = a;

for i=1:K-1,
    L = length(S);
    dist = zeros(1,L);
    if length(a1) == 1,
        m = Data(a1(1,:),:);
    else
        m = mean(Data(a1(1,:),:));
    end
    
    for i1=1:L, 
        x = Data(S(i1),:);
        dist(i1) = norm(x-m);
    end
        
    [temp pos] = min(dist);
     a1(i+1) = S(pos);
     S = setdiff(S, S(pos));
end


% second part of TFRP method
function [SSE, numC,P,N] = TFRP_P2(Data,K,P,N,numC)

GSSE = zeros(numC,1);
Centroints = zeros(numC,size(Data,2));

for i1=1:numC,
    GSSE(i1) = getSSE(Data,P(i1,1:N(i1)));
    Centroints(i1,:) =  mean(Data(P(i1,1:N(i1)),:));
end

[temp,pos] = sort(GSSE,'descend');

merge = [];
for i=1:numC,
    
   
    Ptemp = P;
    Ntemp = N;
    for j=1:N(pos(i)),
        minD = 1000000000.0;
        for i1=1:numC,
            if i1 ~= pos(i) && N(i1) > 0,
                d = norm(Centroints(i1,:)-Data(P(pos(i),j),:));
                if d < minD,
                    minD = d;
                    bestClass = i1;
                end
            end
        end
        Ptemp(bestClass,Ntemp(bestClass)+1) = P(pos(i),j);
        Ntemp(bestClass) = Ntemp(bestClass)+1;
    end
    Ntemp(pos(i)) = 0;
    GSSEtemp = zeros(numC,1);
    for i1=1:numC,
        if Ntemp(i1) > 0,
            GSSEtemp(i1) = getSSE(Data,Ptemp(i1,1:Ntemp(i1)));
        end
    end
    
    if sum(GSSEtemp) < sum(GSSE),
        P = Ptemp;
        N = Ntemp;
        GSSE = GSSEtemp;
        merge = [merge pos(i)];
    end
end
Ptemp = P;
Ntemp = N;
id = 1;
for i=1:numC,
    if Ntemp(i) > 0,
        P(id,:) = Ptemp(i,:);
        N(id) = Ntemp(i);
        id = id+1;
    end
end

numC = numC-length(merge);
N = N(1:numC);
P = P(1:numC,:);
[SSE,numC,P,N] = improvePartitionDiameterCrit(Data,P,N,K);


%GSMS method 
function [SSE, numC,P,N] = GSMS(Data,K)

n = size(Data,1);
Dist = zeros(n,n);
Dist_sorted = zeros(n,n);
Dist_pos = zeros(n,n);
for i=1:n,
    for j=i+1:n,
        Dist(i,j) = norm(Data(i,:)-Data(j,:))^2;
        Dist(j,i) = Dist(i,j);
    end
    [Dist_sorted(i,:),Dist_pos(i,:)] = sort(Dist(i,:)); 
end


SET = [1:n];
N = zeros(floor(n/K),1);
P = zeros(floor(n/K),K);

for i=1:floor(n/K),
    Error = zeros(length(SET),1);
    for j=1:length(SET),
        node = SET(j);
        [vec pos] = intersect(Dist_pos(node,:),SET);
        [temp, pos] = sort(pos);
        vec = vec(pos);
        nodes1 = vec(1:K);
        
        nodes2 = setdiff(SET,nodes1);
        Error(j) = getSSE(Data,nodes1)+getSSE(Data,nodes2);
        
    end
       
    
   [temp,j] = min(Error);
   node = SET(j);
   [vec pos] = intersect(Dist_pos(node,:),SET);
   [temp, pos] = sort(pos);
   vec = vec(pos);
   vec = vec(1:K);

   N(i) = K;
   P(i,1:K) = vec;
   SET = setdiff(SET,vec);
end
Centroints = zeros(floor(n/K),size(Data,2));

if ~isempty(SET),
    
    for i=1:floor(n/K),
        Centroints(i,:) =  mean(Data(P(i,1:K),:));
    end
    
    d = zeros(floor(n/K),length(SET));
    for i=1:floor(n/K),
        for j=1:length(SET),
            d(i,j) = norm(Centroints(i,:)-Data(SET(j),:));
        end
    end
    
    for j=1:length(SET),
        [temp, pos] = min(d(:,j));
        P(pos,N(pos)+1) = SET(j);
        N(pos) = N(pos)+1;
    end
    
end
numC = floor(n/K);
SSE = 0;
for i1=1:numC,
    SSE = SSE + getSSE(Data,P(i1,1:N(i1)));
end



function [SSE, numC,P,N] = diameterBasedFixedSize(Data,K)

P = [];
S = [1:size(Data,1)];
k = 0;
N = zeros(1,size(Data,1));

while length(S) >= 2*K,
    L = length(S);
    minDist = -1;
    a = 0;
    b = 0;
    
    for i1=1:L,
      for i2=i1+1:L,
        dist = norm(Data(S(i1),:)-Data(S(i2),:));
        if dist > minDist,
            a = S(i1);
            b = S(i2);
            minDist = dist;
        end
      end
    end
    
    [a1,S] = gather(Data,S,a,K);
    [b1,S] = gather(Data,S,b,K);
    
    k = k+1;
    P(k,:) = a1;
    N(k) = K;
    k = k+1;
    P(k,:) = b1;
    N(k) = K;
   
end
 
if length(S) >= K
    P(k+1,1:length(S)) = S;
    N(k+1) = length(S);
    k = k+1;
else
    L = length(S);
    
    for i1=1:L, 
        p = Data(S(i1),:);
        dist = zeros(1,k-1);
        
        for i2=1:k,
           dist(i2) = norm(p-mean(Data(P(i2,1:N(i2)),:)));
        end
        [temp pos] = min(dist);
        P(pos,N(pos)+1) = S(i1);
        N(pos) = N(pos)+1;
        
    end
end

numC = k;
SSE = 0;
%figure;
for i1=1:k,
    SSE = SSE + getSSE(Data,P(i1,1:N(i1)));
    
 %   plot(Data(P(i1,1:N(i1)),1),Data(P(i1,1:N(i1)),2),'.','Color',[rand rand rand]);
  %  hold on;
end


function [SSE] = getSSE(Data,nodes)

m = mean(Data(nodes,:));
L = length(nodes);
SSE = sum(sum((Data(nodes,:)- ones(L,1)*m).^2));


function [SST] = getSST(Data)

nodes = [1:1:size(Data,1)];
m = mean(Data(nodes,:));
L = length(nodes);
SST = sum(sum((Data(nodes,:)- ones(L,1)*m).^2));




